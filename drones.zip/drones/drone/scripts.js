// Visualization:
var svg_width = 1400;
var svg_height = 1000;
var columnViewHeight = 20;
var margin = { top: 120, right: 50, bottom: 50, left: 50 };
var mode = "row";
var state = 0;
var timeLength, killedByMonth;
var monthLabelFormat = d3.timeFormat("%b");
var timeTaken1, target_sheet_name, data;
const playPath =
  "M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z";
const forwardPath =
  "M500.5 231.4l-192-160C287.9 54.3 256 68.6 256 96v320c0 27.4 31.9 41.8 52.5 24.6l192-160c15.3-12.8 15.3-36.4 0-49.2zm-256 0l-192-160C31.9 54.3 0 68.6 0 96v320c0 27.4 31.9 41.8 52.5 24.6l192-160c15.3-12.8 15.3-36.4 0-49.2z";

function onLoad() {
  var url = "data/data.xlsx";
  var oReq = new XMLHttpRequest();
  oReq.open("GET", url, true);
  oReq.responseType = "arraybuffer";

  oReq.onload = function (e) {
    d3.json("assets/world_countries.json").then(function (json) {
      var mapHeight = 800,
        mapWidth = 1400;
      var leftProjection = d3
        .geoMercator()
        .translate([mapWidth / 2, mapHeight / 2])
        .center([60, 30.7])
        .scale([400]);

      var leftSVG = d3
        .select("#select-map")
        .append("svg")
        .attr("width", mapWidth)
        .attr("height", mapHeight);

      var leftG = leftSVG.append("g");

      var leftPath = d3.geoPath().projection(leftProjection);

      var leftCentroids = json.features.map(function (feature) {
        return leftPath.centroid(feature);
      });

      var countryOfInterest = ["Afghanistan", "Pakistan", "Somalia", "Yemen"];

      var mapPoints = [
        { country: "Afghanistan", x: 785, y: 240 },
        { country: "Pakistan", x: 810, y: 255 },
        { country: "Somalia", x: 605, y: 500 },
        { country: "Yemen", x: 615, y: 400 },
      ];

      var bombPoints = [
        [790, 235],
        [775, 260],
        [750, 255],
        [745, 280],
        [820, 240],
        [800, 295],
        [760, 305],
        [780, 325],
        [605, 495],
        [630, 470],
        [650, 435],
        [620, 405],
        [635, 395],
        [655, 385],
      ];

      var countries = leftG
        .selectAll(".country")
        .data(json.features)
        .enter()
        .append("path")
        .attr("d", leftPath)
        .attr("class", "country")
        .attr("fill", "#242424");

      var countries = leftG
        .selectAll(".country-interest")
        .data(
          json.features.filter(function (d) {
            return countryOfInterest.indexOf(d.properties.name) >= 0;
          })
        )
        .enter()
        .append("path")
        .attr("d", leftPath)
        .attr("class", "country-interest")
        .attr("id", function (d) {
          return "country_" + d.properties.name.replace(/ /g, "-");
        })
        .attr("fill", "#242424")
        .style("stroke-width", function (d) {
          if (countryOfInterest.indexOf(d.properties.name) >= 0) {
            return 0.5;
          } else {
            return 0;
          }
        })
        .style("stroke", "grey")
        .style("cursor", function (d) {
          if (countryOfInterest.indexOf(d.properties.name) >= 0) {
            return "pointer";
          } else {
            return "default";
          }
        })
        .on("mouseover", function (d) {
          d3.select(this).style("stroke-width", 1.5).attr("fill", "#474747");
        })
        .on("mouseout", function () {
          d3.selectAll(".country-interest")
            .style("stroke-width", 0.5)
            .attr("fill", "#242424");
        })
        .on("click", function (d, index) {
          prelude(index);
        });

      /*leftG
        .selectAll(".country-circle")
        .data(mapPoints)
        .enter()
        .append("circle")
        .attr("class", "country-circle")
        .attr("r", 4.5)
        .attr("cx", function(d, i) {
          return d.x - 20
        })
        .attr("cy", function(d, i) {
          return d.y + 120
        })
        .attr("fill", "red")*/

      leftG
        .selectAll("map-labels")
        .data(mapPoints)
        .enter()
        .append("text")
        .attr("class", "map-labels")
        .attr("x", function (d, i) {
          if (d.country === "Pakistan") {
            return d.x - 35;
          } else {
            return d.x - 30;
          }
        })
        .attr("y", function (d, i) {
          if (d.country === "Pakistan") {
            return d.y + 145;
          } else {
            if (d.country === "Afghanistan") {
              return d.y + 125;
            } else {
              return d.y + 120;
            }
          }
        })
        .text(function (d) {
          return d.country;
        })
        .style("text-anchor", function (d) {
          if (d.country === "Pakistan") {
            return "start";
          } else {
            return "end";
          }
        });

      leftSVG
        .append("text")
        .attr("class", "map-instructions")
        .text("Select Country")
        .attr("x", mapWidth / 2)
        .attr("y", mapHeight / 3);

      function random_bomb() {
        var bomb_size = 5 + Math.round(Math.random() * 15);
        var bomb_index = Math.round(Math.random() * (bombPoints.length - 1));

        leftG
          .append("circle")
          .attr("id", "map-bomb-" + id)
          .attr("r", bomb_size / 2)
          .attr("cx", function () {
            return bombPoints[bomb_index][0] - 20;
          })
          .attr("cy", function () {
            return bombPoints[bomb_index][1] + 120;
          })
          .attr("fill", "red")
          .style("opacity", 0.9)
          .style("pointer-events", "none");

        d3.select("#map-bomb-" + id)
          .transition()
          .duration(1500)
          .delay(0)
          .style("opacity", 0)
          .attr("r", bomb_size);
        id++;
      }

      id = 0;
      setInterval(function () {
        random_bomb();
      }, 1000);
    });

    function prelude(countryChoice) {
      var arraybuffer = oReq.response;

      /* convert data to binary string */
      data = new Uint8Array(arraybuffer);
      var arr = new Array();
      for (var i = 0; i != data.length; ++i)
        arr[i] = String.fromCharCode(data[i]);
      var bstr = arr.join("");

      /* Call XLSX */
      var workbook = XLSX.read(bstr, {
        type: "binary",
      });

      /* DO SOMETHING WITH workbook HERE */
      target_sheet_name = workbook.SheetNames[+countryChoice];

      /* Get worksheet */
      var worksheet = workbook.Sheets[target_sheet_name];
      data = XLSX.utils.sheet_to_json(worksheet, {
        raw: true,
      });

      data.forEach(function (v) {
        v["Date"] =
          v["Date"].split("--")[2] +
          "-" +
          v["Date"].split("--")[1] +
          "-" +
          v["Date"].split("--")[0];
      });

      var minDate = d3.min(data, function (v) {
        return new Date(v["Date"]).getFullYear();
      });

      var totalKilled = d3.sum(data, function (v) {
        return +v["Maximum people killed"];
      });

      d3.select(".map-background").style(
        "background",
        "url(assets/" +
          target_sheet_name.toLowerCase() +
          ".png) 50% 0px no-repeat rgba(0, 0, 0, 0.1)"
      );
      d3.select("#select-map").style("display", "none");
      d3.select(".header").style("display", "block");

      d3.select(".prelude-message-0").text(
        "Since " +
          minDate +
          ", drone strikes have killed an estimated " +
          totalKilled +
          " people in " +
          target_sheet_name +
          "."
      );
      d3.select(".prelude-message-1").text(
        "This is the story of every known drone strike in " +
          target_sheet_name +
          "."
      );

      setTimeout(function () {
        d3.select(".prelude-message-0")
          .style("display", "block")
          .transition()
          .duration(1000)
          .style("opacity", 1);

        setTimeout(function () {
          d3.select(".prelude-message-0")
            .transition()
            .duration(4000)
            .style("opacity", 0);

          setTimeout(function () {
            d3.select(".prelude-message-0").style("display", "none");

            d3.select(".prelude-message-1")
              .style("display", "block")
              .transition()
              .duration(1000)
              .style("opacity", 1);

            setTimeout(function () {
              d3.select(".prelude-message-1")
                .transition()
                .duration(4000)
                .style("opacity", 0);

              setTimeout(init(countryChoice), 16000);
            }, 4000);
          }, 5000);
        }, 1000);
      }, 1000);
    }

    function init(countryChoice) {
      //preprocess dates:
      d3.select(".prelude-message-1").style("display", "none");

      if (target_sheet_name !== "Pakistan") {
        d3.select(".info-header").html("");
        d3.select(".info-body").html("");
      }

      console.log(data);

      var minDate = d3.min(data, function (v) {
        return new Date(v["Date"]);
      });
      var maxDate = d3.max(data, function (v) {
        return new Date(v["Date"]);
      });

      maxDate = d3.timeYear.ceil(maxDate);
      minDate = d3.timeYear.floor(minDate);

      timeLength = d3.timeYear.range(minDate, maxDate);

      killedByMonth = d3
        .nest()
        .key(function (v) {
          return v["Date"].split("-")[0] + "-" + v["Date"].split("-")[1];
        })
        /*.rollup(function (v) {
        var totalKilledMax = d3.sum(v, function (d) {
          return +d["Maximum people killed"];
        });
        return totalKilledMax;
      })*/
        .entries(data);

      var maxKilled = d3.max(killedByMonth, function (v) {
        var totalKilledMax = d3.sum(v.values, function (d) {
          return +d["Maximum people killed"];
        });
        return totalKilledMax;
      });

      var svg = d3
        .select("#viz")
        .append("svg")
        .attr("width", svg_width)
        .attr("height", svg_height)
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

      d3.select(".gradient-image").style("width", window.innerWidth + "px");

      svg
        .append("path")
        .attr("fill", "white")
        .attr("d", playPath)
        .attr("transform", "translate(-40,10) scale(0.03)")
        .attr("opacity", 0.7)
        .style("display", "none")
        .style("cursor", "pointer")
        .on("mouseover", function () {
          d3.select(this).attr("opacity", 1);
        })
        .on("mouseout", function () {
          d3.select(this).attr("opacity", 0.7);
        });

      svg
        .append("path")
        .attr("fill", "black")
        .style("stroke", "white")
        .style("stroke-width", 20)
        .attr("d", forwardPath)
        .attr("transform", "translate(-10,8) scale(0.04)")
        .attr("opacity", 0.7)
        .style("display", "none")
        .style("cursor", "pointer")
        .on("mouseover", function () {
          d3.select(this).attr("opacity", 1);
        })
        .on("mouseout", function () {
          d3.select(this).attr("opacity", 0.7);
        });

      console.log("minDate", minDate);
      console.log("maxDate", maxDate);
      console.log(
        "maxDate-mindate",
        maxDate.getFullYear() - minDate.getFullYear()
      );

      var xScaleRow = d3
        .scaleTime()
        .domain([minDate, maxDate]) // input
        .range([0, svg_width - margin.left - margin.right]); // output

      if (target_sheet_name === "Pakistan") {
        var yScaleColumn = d3
          .scaleTime()
          .domain([maxDate, minDate]) // input
          .range([40, timeLength.length * 12 * columnViewHeight]); // output
      } else {
        var yScaleColumn = d3
          .scaleTime()
          .domain([maxDate, minDate]) // input
          .range([-120, timeLength.length * 12 * columnViewHeight]); // output
      }

      var yScaleRow = d3
        .scaleLinear()
        .domain([0, maxKilled * 2])
        .range([
          (svg_height - margin.top - margin.bottom) / 3 + 25,
          svg_height - margin.top - margin.bottom,
        ]);

      var xScaleColumn = d3
        .scaleLinear()
        .domain([0, maxKilled * 2])
        .range([160, svg_width - margin.left - margin.right]);

      labelData = [];
      xScaleRow
        .ticks(maxDate.getFullYear() - minDate.getFullYear())
        .slice(0, -1)
        .forEach(function (v) {
          labelData.push({ columnX: 0, rowX: 0, date: v });
        });

      svg
        .selectAll(".year-lines")
        .data(labelData)
        .enter()
        .append("line")
        .attr("class", "year-lines")
        .attr("x1", function (d) {
          var X = xScaleRow(
            new Date(d.date).setFullYear(new Date(d.date).getFullYear() + 1)
          );
          return X;
        })
        .attr("x2", function (d) {
          var X = xScaleRow(
            new Date(d.date).setFullYear(new Date(d.date).getFullYear() + 1)
          );
          return X;
        })
        .attr("y1", (svg_height - margin.top - margin.bottom) / 3)
        .attr("y2", (svg_height - margin.top - margin.bottom) / 3 + 10)
        .style("opacity", 0);
      /*.style("opacity", function (d, i) {
        if (i === labelData.length - 1) {
          return 0;
        } else {
          return 1;
        }
      });*/

      var dummyDate = minDate;
      var xScaleWidth =
        (xScaleRow(dummyDate.setMonth(dummyDate.getMonth() + 12)) -
          xScaleRow(dummyDate.setMonth(dummyDate.getMonth() - 12))) /
        2;

      d3.select(".x-axis")
        .selectAll("line")
        .attr("y1", -11)
        .attr("y2", -4)
        .style("display", function (d, i) {
          if (i === 0) {
            return "none";
          }
        });

      chartData = [];
      killedByMonth.forEach(function (v) {
        var index = 0;
        v.values.forEach(function (w, j) {
          for (let i = 0; i < w["Maximum people killed"]; i++) {
            if (i < w["Maximum children reported killed"]) {
              type = "child";
            } else {
              if (i < w["Maximum civilians reported killed"]) {
                type = "civilian";
              } else {
                type = "other";
              }
            }
            var obj = {
              index: index,
              index2: j,
              data: w,
              block: v.key,
              type: type,
            };
            chartData.push(obj);
            index++;
          }
        });
      });

      chartData.forEach(function (d) {
        killedByMonth.forEach(function (v, i) {
          if (d.block === v.key) {
            d.indexTracker = i;
          }
        });
      });

      console.log("chartData", chartData);

      console.log("killedByMonth", killedByMonth);

      attackVictimData = [];
      timeLength.forEach(function (u) {
        var year = new Date(u).getFullYear();
        for (let i = 1; i <= 12; i++) {
          var date = new Date(year, i - 1);
          var month = monthLabelFormat(date);
          var victims = 0;
          var attacks = 0;
          if (i < 10) {
            var id = year + "-0" + i;
          } else {
            var id = year + "-" + i;
          }
          killedByMonth.forEach(function (v) {
            if (v.key === id) {
              attacks = v.values.length;
              victims = d3.sum(v.values, function (w) {
                return w["Maximum people killed"];
              });
            }
          });
          if (date <= new Date()) {
            attackVictimData.push({
              key: id,
              date: date,
              label: month,
              victims: victims,
              attacks: attacks,
            });
          }
        }
      });

      //updateSummary();

      //initalize summary
      d3.select(".summary-bar").style("width", window.innerWidth + "px");
      d3.select(".children-stat").style(
        "width",
        Math.floor(0.3333 * window.innerWidth) + "px"
      );
      d3.select(".value-0").text(0);
      d3.select(".pct-0").text("0%");

      d3.select(".civilian-stat").style(
        "width",
        Math.floor(0.3333 * window.innerWidth) + "px"
      );
      d3.select(".value-1").text(0);
      d3.select(".pct-1").text("0%");

      d3.select(".other-stat").style(
        "width",
        Math.floor(0.3333 * window.innerWidth) + "px"
      );
      d3.select(".value-2").text(0);
      d3.select(".pct-2").text("0%");

      d3.select(".total-value").text(0);

      svg
        .selectAll(".attacks-circles")
        .data(attackVictimData)
        .enter()
        .append("circle")
        .attr("class", "attacks-circles")
        .each(function (d) {
          d.rowX = xScaleRow(d3.timeMonth.floor(new Date(d.date)));
          d.rowY = 295;
          d.columnY = yScaleColumn(d3.timeMonth.floor(new Date(d.date))) + 16.5;
          d.columnAttacksX = 40;
          d.columnVictimsX = 120;
          d.columnMonthLabelsX = 130;
        })
        .style("opacity", 0)
        .attr("cx", function (d) {
          return d.rowX;
        })
        .attr("cy", function (d) {
          return d.rowY;
        })
        .attr("r", 0.5);

      svg
        .append("text")
        .attr("class", "summary-label")
        .attr("fill", "white")
        .attr("x", function () {
          return attackVictimData[0].columnAttacksX;
        })
        .attr("y", function () {
          return (
            d3.min(attackVictimData, function (v) {
              return v.columnY;
            }) - 45
          );
        })
        .text("ATTACKS")
        .style("opacity", 0);

      svg
        .append("text")
        .attr("class", "summary-value-label")
        .attr("fill", "white")
        .attr("x", function () {
          return attackVictimData[0].columnAttacksX;
        })
        .attr("y", function () {
          return (
            d3.min(attackVictimData, function (v) {
              return v.columnY;
            }) - 20
          );
        })
        .text(
          d3.sum(attackVictimData, function (v) {
            return v.attacks;
          })
        )
        .style("opacity", 0);

      svg
        .append("text")
        .attr("class", "summary-label")
        .attr("fill", "red")
        .attr("x", function () {
          return attackVictimData[0].columnVictimsX;
        })
        .attr("y", function () {
          return (
            d3.min(attackVictimData, function (v) {
              return v.columnY;
            }) - 45
          );
        })
        .text("VICTIMS")
        .style("opacity", 0);

      svg
        .append("text")
        .attr("class", "summary-value-label")
        .attr("fill", "red")
        .attr("x", function () {
          return attackVictimData[0].columnVictimsX;
        })
        .attr("y", function () {
          return (
            d3.min(attackVictimData, function (v) {
              return v.columnY;
            }) - 20
          );
        })
        .text(
          d3.sum(attackVictimData, function (v) {
            return v.victims;
          })
        )
        .style("opacity", 0);

      svg
        .selectAll(".month-flag-box")
        .data(attackVictimData)
        .enter()
        .append("rect")
        .attr("class", "month-flag-box")
        .attr("x", function (d) {
          return d.rowX - 35;
        })
        .attr("y", function (d) {
          return d.rowY;
        })
        .style("stroke", "#5f5f5f")
        .style("stroke-width", "2px")
        .attr("fill", "black")
        .attr("width", 70)
        .attr("height", 125)
        .style("opacity", 0);

      console.log("attackVictimData", attackVictimData);

      svg
        .selectAll(".month-flag-attacks")
        .data(attackVictimData)
        .enter()
        .append("text")
        .attr("class", "month-flag-attacks")
        .attr("fill", "white")
        .text(function (d) {
          return d.attacks;
        })
        .attr("x", function (d) {
          return d.rowX;
        })
        .attr("y", function (d) {
          return d.rowY + 30;
        })
        .style("opacity", 0);

      svg
        .selectAll(".month-flag-attacks-label")
        .data(attackVictimData)
        .enter()
        .append("text")
        .attr("class", "month-flag-attacks-label")
        .attr("fill", "white")
        .attr("x", function (d) {
          return d.rowX;
        })
        .attr("y", function (d) {
          return d.rowY + 45;
        })
        .text("ATTACKS")
        .style("opacity", 0);

      svg
        .selectAll(".month-flag-deaths")
        .data(attackVictimData)
        .enter()
        .append("text")
        .attr("class", "month-flag-deaths")
        .attr("fill", "white")
        .text(function (d) {
          return d.victims;
        })
        .attr("x", function (d) {
          return d.rowX;
        })
        .attr("y", function (d) {
          return d.rowY + 80;
        })
        .style("opacity", 0);

      svg
        .selectAll(".month-flag-deaths-label")
        .data(attackVictimData)
        .enter()
        .append("text")
        .attr("class", "month-flag-deaths-label")
        .attr("fill", "white")
        .attr("x", function (d) {
          return d.rowX;
        })
        .attr("y", function (d) {
          return d.rowY + 100;
        })
        .text("DEATHS")
        .style("opacity", 0);

      svg
        .selectAll(".month-flag-line")
        .data(attackVictimData)
        .enter()
        .append("line")
        .attr("class", "month-flag-line")
        .attr("x1", function (d) {
          return d.rowX;
        })
        .attr("x2", function (d) {
          return d.rowX;
        })
        .attr("y1", function (d) {
          return d.rowY;
        })
        .attr("y2", function (d) {
          return d.rowY;
        })
        .style("stroke", "white")
        .style("stroke-width", "4px")
        .style("opacity", 0);

      svg
        .selectAll(".attacks-labels")
        .data(attackVictimData)
        .enter()
        .append("text")
        .attr("class", "attacks-labels")
        .attr("fill", "white")
        .attr("x", function (d) {
          return d.rowX;
        })
        .attr("y", function (d) {
          return d.rowY;
        })
        .text(function (d) {
          return d.attacks;
        })
        .style("opacity", 0);

      svg
        .selectAll(".victims-circles")
        .data(attackVictimData)
        .enter()
        .append("circle")
        .attr("class", "victims-circles")
        .style("opacity", 0)
        .attr("cx", function (d) {
          return d.rowX;
        })
        .attr("cy", function (d) {
          return d.rowY;
        })
        .attr("r", 0.5);

      svg
        .selectAll(".victims-labels")
        .data(attackVictimData)
        .enter()
        .append("text")
        .attr("class", "victims-labels")
        .attr("fill", "red")
        .attr("x", function (d) {
          return d.rowX;
        })
        .attr("y", function (d) {
          return d.rowY;
        })
        .text(function (d) {
          return d.victims;
        })
        .style("opacity", 0);

      svg
        .selectAll(".labels-circles")
        .data(attackVictimData)
        .enter()
        .append("circle")
        .attr("class", "labels-circles")
        .style("opacity", 0)
        .attr("cx", function (d) {
          return d.rowX;
        })
        .attr("cy", function (d) {
          return d.rowY;
        })
        .attr("r", 0.5);

      svg
        .selectAll(".labels-labels")
        .data(attackVictimData)
        .enter()
        .append("text")
        .attr("class", "labels-labels")
        .attr("fill", "white")
        .attr("x", function (d) {
          return d.rowX;
        })
        .attr("y", function (d) {
          return d.rowY;
        })
        .text(function (d) {
          return d.label;
        })
        .style("opacity", 0);

      svg
        .selectAll(".play-bombs")
        .data(killedByMonth)
        .enter()
        .append("circle")
        .attr("class", "play-bombs")
        .attr("r", 0)
        .attr("cx", function (d) {
          d.rowX = xScaleRow(d3.timeMonth.floor(new Date(d.values[0].Date)));

          return d.rowX;
        })
        .attr("cy", function (d) {
          d.rowY = 295;
          return d.rowY;
        })
        .attr("fill", "red")
        .style("opacity", 1);

      var lineGenerator = d3.line().curve(d3.curveBasis);

      var gradient = svg
        .append("defs")
        .append("linearGradient")
        .attr("id", "svgGradient")
        .attr("x1", "0%")
        .attr("x2", "0%")
        .attr("y1", "0%")
        .attr("y2", "100%");

      gradient
        .append("stop")
        .attr("class", "start")
        .attr("offset", "0%")
        .attr("stop-color", "#1A1A1A")
        .attr("stop-opacity", 1);

      gradient
        .append("stop")
        .attr("class", "end")
        .attr("offset", "100%")
        .attr("stop-color", "white")
        .attr("stop-opacity", 1);

      svg
        .selectAll(".play-bomb-path")
        .data(killedByMonth)
        .enter()
        .append("path")
        .attr("class", "play-bomb-path")
        .style("stroke", "url(#svgGradient)")
        .attr("fill", "none")
        .each(function (d, i) {
          if (i % 2 == 0) {
            direction = (150 + Math.random() * 250) / 2.5;
          } else {
            direction = -(150 + Math.random() * 250) / 2.5;
          }
          d.points = [
            [d.rowX + direction, 0],
            [d.rowX + direction / 3, d.rowY / 8],
            [d.rowX, d.rowY],
          ];
        })
        .attr("d", function (d) {
          return lineGenerator(d.points);
        })
        .each(function (d) {
          d.totalLength = d3.select(this).node().getTotalLength();
        })
        .attr("stroke-dasharray", function (d) {
          return d.totalLength + " " + d.totalLength;
        })
        .attr("stroke-dashoffset", function (d) {
          return d.totalLength;
        });

      svg
        .selectAll(".year-label-blocks")
        .data(labelData)
        .enter()
        .append("rect")
        .attr("class", "year-label-blocks")
        .style("opacity", 0)
        .attr("x", function (d, i) {
          d.columnY = yScaleColumn(new Date(d.date)) + 15.5;
          d.rowX =
            (xScaleRow(
              new Date(d.date).setFullYear(new Date(d.date).getFullYear() + 1)
            ) -
              xScaleRow(new Date(d.date))) /
              2 +
            xScaleRow(new Date(d.date));
          return d.rowX - 16;
        })
        .attr("y", (svg_height - margin.top - margin.bottom) / 3 + 1)
        .attr("fill", "#1A1A1A")
        .attr("width", 32)
        .attr("height", 10);

      console.log("labelData", labelData);

      svg
        .selectAll(".year-labels")
        .data(labelData)
        .enter()
        .append("text")
        .attr("class", "year-labels")
        .style("opacity", 0)
        .attr("x", function (d, i) {
          return d.rowX;
        })
        .attr("y", (svg_height - margin.top - margin.bottom) / 3 + 10)
        .text(function (d) {
          return new Date(d.date).getFullYear();
        });

      svg
        .append("rect")
        .attr("class", "utility-rect")
        .attr("width", window.innerWidth)
        .attr("height", window.innerHeight / 2)
        .attr("x", -40)
        .attr("y", 295)
        .attr("fill", "black");

      svg
        .selectAll(".deaths")
        .data(chartData)
        .enter()
        .append("rect")
        .attr("class", "deaths")
        .each(function (d) {
          d.rowWidth = xScaleWidth / 7;
          d.rowHeight = yScaleRow(maxKilled) / (maxKilled * 1.5);
          d.rowX =
            xScaleRow(d3.timeMonth.floor(new Date(d.data.Date))) -
            d.rowWidth / 2;
          d.rowY = yScaleRow(d.index * 2);
          d.columnX = xScaleColumn(d.index * 2);
          d.columnY = yScaleColumn(d3.timeMonth.floor(new Date(d.data.Date)));
          d.columnWidth = 8;
          d.columnHeight = 20;
        })
        .attr("x", function (d) {
          return d.rowX;
        })
        .attr("y", function (d) {
          return d.rowY;
        })
        .attr("width", function (d) {
          return d.rowWidth;
        })
        .attr("height", function (d) {
          return d.rowHeight;
        })
        .attr("fill", function (d) {
          if (d.type === "child") {
            return "#CC0000";
          }
          if (d.type === "civilian") {
            return "#620000";
          }
          if (d.type === "other") {
            return "#CCCCCC";
          }
        })
        .style("opacity", 0)
        .on("mouseover", function (d) {
          if (state === 1) {
            showDeathTooltip(d);
          }
        })
        .on("mouseout", function (d) {
          if (state === 1) {
            hideDeathTooltip();
          }
        });

      svg
        .selectAll(".deaths-images")
        .data(chartData)
        .enter()
        .append("image")
        .attr("xlink:href", function (d) {
          if (d.type === "child") {
            return "assets/person_child.svg";
          }
          if (d.type === "civilian") {
            return "assets/person_civilian.svg";
          }
          if (d.type === "other") {
            return "assets/person_other.svg";
          }
        })
        .attr("class", "deaths-images")
        .attr("x", function (d) {
          return d.rowX;
        })
        .attr("y", function (d) {
          return d.rowY;
        })
        .attr("width", function (d) {
          return d.rowHeight;
        })
        .attr("height", function (d) {
          return d.rowWidth;
        })
        .style("transform", "rotate(90)")
        .on("mouseover", function (d) {
          if (state === 1) {
            showDeathTooltip(d);
          }
        })
        .on("mouseout", function (d) {
          if (state === 1) {
            hideDeathTooltip();
          }
        })
        .style("opacity", 0);

      d3.select(".controls-attacks").on("click", function () {
        if (state === 1) {
          d3.select(".controls-attacks").attr(
            "class",
            "controls-attacks active"
          );
          d3.select(".controls-victims").attr("class", "controls-victims");
          if (mode === "column") {
            toggleMode();
          }
        }
      });

      d3.select(".close").on("click", function () {
        d3.select(".info-bg").style("display", "none");
        d3.select("#info-container").style("display", "none");
      });

      d3.select(".controls-info").on("click", function () {
        if (state === 1) {
          d3.select(".info-bg").style("display", "block");
          d3.select("#info-container").style("display", "block");
        }
      });

      d3.select(".controls-victims").on("click", function () {
        if (state === 1) {
          d3.select(".controls-victims").attr(
            "class",
            "controls-victims active"
          );
          d3.select(".controls-attacks").attr("class", "controls-attacks");
          if (mode === "row") {
            toggleMode();
          }
        }
      });

      d3.select(".back-button").on("click", function () {
        if (state === 1) {
          location.reload();
        }
      });

      d3.select(".gradient-image").style("display", "block");
      d3.select(".title").style("display", "block");

      d3.selectAll(".year-labels")
        .transition()
        .duration(1000)
        .delay(function (d, i) {
          return 200 * i;
        })
        .style("opacity", 1);

      d3.selectAll(".year-label-blocks")
        .transition()
        .duration(1000)
        .delay(function (d, i) {
          return 200 * i;
        })
        .style("opacity", 1);

      d3.selectAll(".year-lines")
        .transition()
        .duration(1000)
        .delay(function (d, i) {
          return 200 * i;
        })
        .style("opacity", function (d, i) {
          if (i === labelData.length - 1) {
            return 0;
          } else {
            return 1;
          }
        });

      d3.selectAll(".attacks-circles")
        .transition()
        .duration(1000)
        .delay(function (d, i) {
          return 15 * i;
        })
        .style("opacity", 1);

      d3.selectAll(".victims-circles")
        .transition()
        .duration(1000)
        .delay(function (d, i) {
          return 15 * i;
        })
        .style("opacity", 1);

      d3.selectAll(".labels-circles")
        .transition()
        .duration(1000)
        .delay(function (d, i) {
          return 15 * i;
        })
        .style("opacity", 1);

      var timeTaken0 = labelData.length * 200 + 1000;

      d3.select(".summary-bar-container")
        .transition()
        .duration(1000)
        .delay(timeTaken0)
        .style("opacity", 1);

      d3.select(".controls-container")
        .transition()
        .duration(1000)
        .delay(timeTaken0 + 300)
        .style("opacity", 1);

      d3.select(".map-background")
        .transition()
        .duration(1000)
        .delay(timeTaken0 + 600)
        .style("opacity", 1);

      d3.select(".total-container")
        .transition()
        .duration(1000)
        .delay(timeTaken0 + 600)
        .style("opacity", 1);

      d3.select(".back-button")
        .transition()
        .duration(1000)
        .delay(timeTaken0 + 600)
        .style("opacity", 1);

      timeTaken1 = timeTaken0 + 1600;

      setTimeout(play, timeTaken1);
    }

    function play() {
      d3.selectAll(".deaths")
        .transition()
        .duration(100)
        .delay(function (d, i) {
          return Math.round(d.index * 5) + d.indexTracker * 500;
        })
        .style("opacity", 1);

      d3.selectAll(".play-bombs")
        .transition()
        .duration(2000)
        .delay(function (d, i) {
          return i * 500;
        })
        .attr("r", 50)
        .style("opacity", 0);

      d3.selectAll(".play-bomb-path")
        .transition()
        .duration(700)
        .delay(function (d, i) {
          return i * 500 - 500;
        })
        .attr("stroke-dashoffset", 0);

      // update summary
      var count = 0;
      var timer = setInterval(function () {
        updateSummary(count);

        if (count === killedByMonth.length - 1) {
          state = 1;
          clearInterval(timer);
        }
        count++;
      }, 500);
    }
  };

  oReq.send();
}

function toggleMode() {
  if (mode === "column") {
    mode = "row";
    d3.select(".gradient-image").style("display", "block");
    d3.select("#viz")
      .select("svg")
      .transition()
      .duration(0)
      .delay(2000)
      .attr("height", svg_height);
    d3.select(".utility-rect").style("display", "block");
    d3.selectAll(".year-label-blocks")
      .transition()
      .duration(500)
      .delay(1500)
      .style("opacity", 1);
    d3.selectAll(".play-bomb-path")
      .transition()
      .duration(500)
      .delay(1500)
      .style("opacity", 1);
    d3.selectAll(".year-labels")
      .transition()
      .duration(2000)
      .attr("x", function (d) {
        return d.rowX;
      })
      .attr("y", (svg_height - margin.top - margin.bottom) / 3 + 10);

    d3.selectAll(".summary-value-label")
      .transition()
      .duration(1000)
      .style("opacity", 0);

    d3.selectAll(".summary-label")
      .transition()
      .duration(1000)
      .style("opacity", 0);

    d3.selectAll(".deaths")
      .transition()
      .duration(2000)
      .attr("x", function (d) {
        return d.rowX;
      })
      .attr("y", function (d) {
        return d.rowY;
      })
      .attr("width", function (d) {
        return d.rowWidth;
      })
      .attr("height", function (d) {
        return d.rowHeight;
      })
      .style("opacity", 1);

    d3.selectAll(".deaths-images")
      .transition()
      .duration(2000)
      .attr("x", function (d) {
        return d.rowX;
      })
      .attr("y", function (d) {
        return d.rowY;
      })
      .attr("width", function (d) {
        return d.rowHeight;
      })
      .attr("height", function (d) {
        return d.rowWidth;
      })
      .style("transform", "rotate(90)")
      .style("opacity", 0);

    d3.selectAll(".attacks-circles")
      .transition()
      .duration(2000)
      .attr("cx", function (d) {
        return d.rowX;
      })
      .attr("cy", function (d) {
        return d.rowY;
      })
      .attr("r", 0.5)
      .style("opacity", 1);

    d3.selectAll(".attacks-labels")
      .transition()
      .duration(2000)
      .attr("x", function (d) {
        return d.rowX;
      })
      .attr("y", function (d) {
        return d.rowY;
      })
      .style("opacity", 0);

    d3.selectAll(".victims-circles")
      .transition()
      .duration(2000)
      .attr("cx", function (d) {
        return d.rowX;
      })
      .attr("cy", function (d) {
        return d.rowY;
      })
      .attr("r", 0.5)
      .style("opacity", 1);

    d3.selectAll(".victims-labels")
      .transition()
      .duration(2000)
      .attr("x", function (d) {
        return d.rowX;
      })
      .attr("y", function (d) {
        return d.rowY;
      })
      .style("opacity", 0);

    d3.selectAll(".labels-circles")
      .transition()
      .duration(2000)
      .attr("cx", function (d) {
        return d.rowX;
      })
      .attr("cy", function (d) {
        return d.rowY;
      })
      .attr("r", 0.5)
      .style("opacity", 1);

    d3.selectAll(".labels-labels")
      .transition()
      .duration(2000)
      .attr("x", function (d) {
        return d.rowX;
      })
      .attr("y", function (d) {
        return d.rowY;
      })
      .style("opacity", 0);

    d3.selectAll(".year-lines")
      .transition()
      .duration(1000)
      .delay(1000)
      .style("opacity", function (d, i) {
        if (i === labelData.length - 1) {
          return 0;
        } else {
          return 1;
        }
      });
  } else {
    mode = "column";
    d3.select(".gradient-image").style("display", "none");
    d3.select(".utility-rect").style("display", "none");
    if (target_sheet_name === "Pakistan") {
      d3.select("#viz")
        .select("svg")
        .attr("height", timeLength.length * 12 * columnViewHeight + 400);
    } else {
      d3.select("#viz")
        .select("svg")
        .attr("height", timeLength.length * 12 * columnViewHeight + 200);
    }
    d3.select("#viz")
      .select("svg")
      .attr("height", timeLength.length * 12 * columnViewHeight + 200);
    d3.selectAll(".year-labels")
      .transition()
      .duration(2000)
      .attr("x", -20)
      .attr("y", function (d) {
        return d.columnY;
      });
    d3.selectAll(".year-label-blocks")
      .transition()
      .duration(500)
      .style("opacity", 0);
    d3.selectAll(".play-bomb-path")
      .transition()
      .duration(500)
      .style("opacity", 0);

    d3.selectAll(".summary-value-label")
      .transition()
      .duration(1000)
      .delay(1000)
      .style("opacity", 1);

    d3.selectAll(".summary-label")
      .transition()
      .duration(1000)
      .delay(1000)
      .style("opacity", 1);

    d3.selectAll(".deaths")
      .transition()
      .duration(2000)
      .attr("x", function (d) {
        return d.columnX;
      })
      .attr("y", function (d) {
        return d.columnY;
      })
      .attr("width", function (d) {
        return d.columnWidth;
      })
      .attr("height", function (d) {
        return d.columnHeight;
      })
      .style("opacity", 0);

    d3.selectAll(".deaths-images")
      .transition()
      .duration(2000)
      .attr("x", function (d) {
        return d.columnX;
      })
      .attr("y", function (d) {
        return d.columnY;
      })
      .attr("width", function (d) {
        return d.columnWidth;
      })
      .attr("height", function (d) {
        return d.columnHeight;
      })
      .style("transform", "rotate(0)")
      .style("opacity", 1);

    d3.selectAll(".attacks-circles")
      .transition()
      .duration(2000)
      .attr("cx", function (d) {
        return d.columnAttacksX;
      })
      .attr("cy", function (d) {
        return d.columnY;
      })
      .attr("r", function (d) {
        return 5;
      })
      .style("opacity", 0);

    d3.selectAll(".attacks-labels")
      .transition()
      .duration(2000)
      .attr("x", function (d) {
        return d.columnAttacksX;
      })
      .attr("y", function (d) {
        return d.columnY;
      })
      .style("opacity", 1);

    d3.selectAll(".victims-circles")
      .transition()
      .duration(2000)
      .attr("cx", function (d) {
        return d.columnVictimsX;
      })
      .attr("cy", function (d) {
        return d.columnY;
      })
      .attr("r", function (d) {
        return 5;
      })
      .style("opacity", 0);

    d3.selectAll(".victims-labels")
      .transition()
      .duration(2000)
      .attr("x", function (d) {
        return d.columnVictimsX;
      })
      .attr("y", function (d) {
        return d.columnY;
      })
      .style("opacity", 1);

    d3.selectAll(".labels-circles")
      .transition()
      .duration(2000)
      .attr("cx", function (d) {
        return d.columnMonthLabelsX;
      })
      .attr("cy", function (d) {
        return d.columnY;
      })
      .attr("r", function (d) {
        return 3;
      })
      .style("opacity", 0);

    d3.selectAll(".labels-labels")
      .transition()
      .duration(2000)
      .attr("x", function (d) {
        return d.columnMonthLabelsX;
      })
      .attr("y", function (d) {
        return d.columnY;
      })
      .style("opacity", 1);

    d3.selectAll(".year-lines").transition().duration(1000).style("opacity", 0);
  }
}

function updateSummary(playIndex) {
  var tempkilledByMonth = killedByMonth.filter(function (d, i) {
    return i <= playIndex;
  });

  var totalDeaths = d3.sum(tempkilledByMonth, function (d) {
    return d3.sum(d.values, function (v) {
      return v["Maximum people killed"];
    });
  });

  var childrenDeaths = d3.sum(tempkilledByMonth, function (d) {
    return d3.sum(d.values, function (v) {
      return v["Maximum children reported killed"];
    });
  });

  var totalCivilianDeaths = d3.sum(tempkilledByMonth, function (d) {
    return d3.sum(d.values, function (v) {
      return v["Maximum civilians reported killed"];
    });
  });
  var civilianDeaths = totalCivilianDeaths - childrenDeaths;
  var otherDeaths = totalDeaths - civilianDeaths - childrenDeaths;

  d3.select(".children-stat").style(
    "width",
    Math.floor((childrenDeaths / totalDeaths) * window.innerWidth) + "px"
  );
  d3.select(".value-0").text(childrenDeaths);
  d3.select(".pct-0").text(
    Math.round((childrenDeaths * 100) / totalDeaths) + "%"
  );
  d3.select(".civilian-stat").style(
    "width",
    Math.floor((civilianDeaths / totalDeaths) * window.innerWidth) + "px"
  );
  d3.select(".value-1").text(civilianDeaths);
  d3.select(".pct-1").text(
    Math.round((civilianDeaths * 100) / totalDeaths) + "%"
  );

  d3.select(".other-stat").style(
    "width",
    Math.floor((otherDeaths / totalDeaths) * window.innerWidth) + "px"
  );
  d3.select(".value-2").text(otherDeaths);
  d3.select(".pct-2").text(Math.round((otherDeaths * 100) / totalDeaths) + "%");

  d3.select(".total-value").text(totalDeaths);
}

function showDeathTooltip(d) {
  d3.select(".tooltip").style("display", "block");
  d3.select(".tooltip-date").text(d.data.Date);
  d3.select(".num-children").text(d.data["Maximum children reported killed"]);
  d3.select(".num-civilians").text(d.data["Maximum civilians reported killed"]);
  d3.select(".num-other").text(
    d.data["Maximum people killed"] -
      d.data["Maximum civilians reported killed"]
  );
  var monthlyTotal;
  attackVictimData.forEach(function (u) {
    if (u.key === d.block) {
      monthlyTotal = u.victims;
    }
  });
  var total = d.data["Maximum people killed"];
  d3.select(".tooltip-monthly-totals").text(
    total + " of " + monthlyTotal + " Deaths that month"
  );
  if (d.data["Province"] !== "" || d.data["Province"] != null) {
    d3.select(".tooltip-where-location").text(
      "Where: " + d.data["Location"] + ", " + d.data["Province"]
    );
  } else {
    d3.select(".tooltip-where-location").text("Where: " + d.data["Location"]);
  }

  let x, y;
  if (mode === "row") {
    x = d3.event.clientX;
    y = d3.event.clientY - 130;
  } else {
    x = d3.event.clientX;
    y = d3.event.clientY - 130;
  }

  d3.select(".tooltip").style("transform", `translate(${x}px,${y}px)`);

  if (mode === "row") {
    d3.selectAll(".deaths").style("opacity", function (u) {
      if (u.block === d.block && u.index2 === d.index2) {
        return 1;
      } else {
        return 0.2;
      }
    });
    d3.selectAll(".month-flag-box")
      .transition()
      .duration(1000)
      .style("opacity", function (u) {
        if (u.key === d.block) {
          return 0.8;
        } else {
          return 0;
        }
      })
      .attr("y", function (u) {
        if (u.key === d.block) {
          return u.rowY - 190;
        } else {
          return u.rowY;
        }
      });

    d3.selectAll(".month-flag-attacks")
      .transition()
      .duration(1000)
      .style("opacity", function (u) {
        if (u.key === d.block) {
          return 1;
        } else {
          return 0;
        }
      })
      .attr("y", function (u) {
        if (u.key === d.block) {
          return u.rowY - 160;
        } else {
          return u.rowY + 30;
        }
      });

    d3.selectAll(".month-flag-attacks-label")
      .transition()
      .duration(1000)
      .style("opacity", function (u) {
        if (u.key === d.block) {
          return 1;
        } else {
          return 0;
        }
      })
      .attr("y", function (u) {
        if (u.key === d.block) {
          return u.rowY - 145;
        } else {
          return u.rowY + 45;
        }
      });

    d3.selectAll(".month-flag-deaths")
      .transition()
      .duration(1000)
      .style("opacity", function (u) {
        if (u.key === d.block) {
          return 1;
        } else {
          return 0;
        }
      })
      .attr("y", function (u) {
        if (u.key === d.block) {
          return u.rowY - 110;
        } else {
          return u.rowY + 80;
        }
      });

    d3.selectAll(".month-flag-deaths-label")
      .transition()
      .duration(1000)
      .style("opacity", function (u) {
        if (u.key === d.block) {
          return 1;
        } else {
          return 0;
        }
      })
      .attr("y", function (u) {
        if (u.key === d.block) {
          return u.rowY - 90;
        } else {
          return u.rowY + 100;
        }
      });

    d3.selectAll(".month-flag-line")
      .attr("y1", function (u) {
        return u.rowY - 64;
      })
      .attr("y2", function (u) {
        return u.rowY - 64;
      })
      .style("opacity", function (u) {
        if (u.key === d.block) {
          return 1;
        } else {
          return 0;
        }
      });

    d3.selectAll(".month-flag-line")
      .transition()
      .duration(1000)
      .delay(1000)
      .attr("y2", function (u) {
        if (u.key === d.block) {
          return u.rowY;
        } else {
          return u.rowY;
        }
      });
  } else {
    d3.selectAll(".deaths-images").style("opacity", function (u) {
      if (u.block === d.block && u.index2 === d.index2) {
        return 1;
      } else {
        return 0.2;
      }
    });
  }
}

function hideDeathTooltip() {
  d3.select(".tooltip").style("display", "none");
  if (mode === "row") {
    d3.selectAll(".deaths").style("opacity", 1);
  } else {
    d3.selectAll(".deaths-images").style("opacity", 1);
  }

  d3.selectAll(".month-flag-box")
    .transition()
    .duration(500)
    .style("opacity", 0)
    .attr("y", function (u) {
      return attackVictimData[0].rowY;
    });
  d3.selectAll(".month-flag-attacks")
    .transition()
    .duration(500)
    .style("opacity", 0)
    .attr("y", function (u) {
      return attackVictimData[0].rowY + 30;
    });
  d3.selectAll(".month-flag-attacks-label")
    .transition()
    .duration(500)
    .style("opacity", 0)
    .attr("y", function (u) {
      return attackVictimData[0].rowY + 45;
    });
  d3.selectAll(".month-flag-deaths")
    .transition()
    .duration(500)
    .style("opacity", 0)
    .attr("y", function (u) {
      return attackVictimData[0].rowY + 80;
    });
  d3.selectAll(".month-flag-deaths-label")
    .transition()
    .duration(500)
    .style("opacity", 0)
    .attr("y", function (u) {
      return attackVictimData[0].rowY + 100;
    });
  d3.selectAll(".month-flag-line")
    //.transition("line-up")
    //.duration(0)
    .style("opacity", 0)
    .attr("y1", function (u) {
      return attackVictimData[0].rowY;
    })
    .attr("y2", function (u) {
      return attackVictimData[0].rowY;
    });
}
